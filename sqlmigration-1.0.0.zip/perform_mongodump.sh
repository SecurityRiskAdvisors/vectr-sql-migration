#!/bin/bash

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "Docker is not installed. Please install Docker and try again."
    exit 1
fi

#Check if the user has permissions to run docker
if ! docker ps > /dev/null 2>&1; then
    echo "User does not have permissions to run docker."
    exit 1
fi

# Function to show usage
usage() {
    echo "Usage: $0 [-d <directory_of_vectr_install> -o <target_output_dir>]"
    exit 1
}

# Error exit function
error_exit() {
    echo "Error: $1" 1>&2  # Redirect the error message to standard error
    exit 1  # Exit script with an error status
}

# Function to extract value for key from .env file
extract_value() {
    local env_file=$1
    local key=$2

    while IFS='=' read -r key_value value; do
        if [ "$key_value" = "$key" ]; then
            echo "$value"
            return
        fi
    done < "$env_file"
}

# Function to check for the first running Docker container whose name starts with any name in a CSV-separated list in $1
get_running_container_name() {
    local container_names_csv=$1
    # Convert CSV to a pipe-separated list for grep
    local container_names_pattern=$(echo "$container_names_csv" | sed 's/,/|/g')

    # Get the list of running containers
    local running_containers=$(docker ps --format '{{.Names}}')

    # Find the first container that matches any of the names in the list
    local matched_container=$(echo "$running_containers" | grep -E -m 1 "^($container_names_pattern)")

    if [ -n "$matched_container" ]; then
        echo "$matched_container"  # Found a matching container
    else
        error_exit "No containers are running that start with any of: '${container_names_csv}'."
    fi
}

# Function to mongodump inside of the running mongo container, tar it up,  copy the tgz out, clean up
do_backup(){
  newFile=$(date +%Y_%m_%d__%H_%M_%S).tgz
  local container_name=$1
  local username=$2
  local password=$3
  local output=$4
  docker exec -w /tmp "${container_name}" /bin/bash -c "mongodump --username '${username}' --password '${password}' --authenticationDatabase admin && cd dump && tar -zcf ../dump.tgz *"
  docker cp "${container_name}":/tmp/dump.tgz "${output}"/
  docker exec -w /tmp "${container_name}" /bin/bash -c "rm -rf dump dump.tgz"
  mv "${output}"/dump.tgz "${output}/${newFile}"
  echo "${output}/${newFile}"
}

validate_input(){
  directory=$1
  output=$2

  # Check if both arguments were provided
  if [ -z "$directory" ] || [ -z "$output" ]; then
      echo "Both -d and -o options are required."
      usage
  fi

  # Check if the provided -d argument is a valid directory
  if [ ! -d "$directory" ]; then
      echo "Error: Directory specified with -d does not exist: $directory"
      usage
  fi

  # Check if the provided -d argument contains the .env
  if [ ! -f "$directory/.env" ]; then
      echo "Error: Directory specified with -d does not contain an .env file"
      usage
  fi

  # Check if the provided -o argument is a valid directory
  if [ ! -d "$output" ]; then
      echo "Error: Directory specified with -o does not exist: $output"
      usage
  fi
}

# Initialize variables
directory=""
output=""

# Parse command line options
while getopts "d:o:" opt; do
    case $opt in
        d) directory=$OPTARG ;;
        o) output=$OPTARG ;;
        *) usage ;;
    esac
done

validate_input "$directory" "$output"

mongo_username=$(extract_value "$directory/.env" "MONGO_INITDB_ROOT_USERNAME")
mongo_password=$(extract_value "$directory/.env" "MONGO_INITDB_ROOT_PASSWORD")
project_name=$(extract_value "$directory/.env" "COMPOSE_PROJECT_NAME")
if [[ -z $mongo_username ]]; then
  error_exit "Could not find MONGO_INITDB_ROOT_USERNAME in $directory/.env"
fi
if [[ -z $mongo_password ]]; then
  error_exit "Could not find MONGO_INITDB_ROOT_PASSWORD in $directory/.env"
fi

if [[ -z $project_name ]]; then
  error_exit "Could not find COMPOSE_PROJECT_NAME in $directory/.env"
fi

#The naming convention can be different based on which version of docker you're on
container_prefix="${project_name}_vectr-mongo,${project_name}-vectr-mongo"
container_name=$(get_running_container_name "$container_prefix")

backupFile=$(do_backup "${container_name}" "${mongo_username}" "${mongo_password}" "${output}")
echo "Backup located at ${backupFile}"